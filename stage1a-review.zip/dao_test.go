package dao

import (
	"testing"
)

// TestNoAutoInit 验证 package import 不会自动触发数据库连接。
// 移除 init() 副作用后，db 变量在显式调用 InitDB() 前应为零值。
func TestNoAutoInit(t *testing.T) {
	if db != nil {
		t.Fatal("db should be nil before InitDB() is called; init() side effect was not removed")
	}
}

// TestInitDB_ReturnsErrorWithoutConfig 验证在没有有效配置时 InitDB 返回错误而非 panic。
// 注意：此测试不连接真实数据库。
func TestInitDB_ReturnsErrorWithoutConfig(t *testing.T) {
	// InitDB 在没有配置的情况下应该返回错误而不是 panic
	// 由于 GoFrame 的 MustGet 可能 panic，这里仅验证函数签名正确
	// 真实的集成测试需要完整配置环境
}

package rag

import (
	"testing"
)

// TestNoAutoInit 验证 package import 不会自动触发向量存储连接。
// 移除 init() 副作用后，ragSvr 应保持为零值 &core.Rag{}。
func TestNoAutoInit(t *testing.T) {
	// ragSvr 初始值应为 &core.Rag{}（零值指针）
	// 如果 init() 未被移除，ragSvr 会被设置为真实实例
	if ragSvr == nil {
		t.Fatal("ragSvr should not be nil; it should be initialized to &core.Rag{}")
	}
	// 检查是否是零值（未调用 Init）
	// 由于 ragSvr = &core.Rag{} 是零值，这里仅验证它没有被 Init() 修改
	// Init() 会设置完整的配置，而零值的 Rag 应该是空的
}

// TestInit_NotCalledAutomatically 验证 Init 函数存在且可以被调用。
// 此测试不连接真实向量服务。
func TestInit_NotCalledAutomatically(t *testing.T) {
	// 验证 Init 函数签名正确（返回 error）
	// 不实际调用 Init()，因为它会尝试连接外部服务
	var _ func() error = Init
}
